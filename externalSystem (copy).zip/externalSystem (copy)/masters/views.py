import json

from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
import masters.models
from masters.models import *
import requests
from requests import session
import uuid
from django.conf import settings as masters_settings

def sec(request):
        if (request.user.username != 'secretary'):
            return render(request, 'updateapproval.html')
        else:
            return redirect('/')

def order(request):
    if (request.user.username != 'professor'):
        return render(request, 'updateorder.html')
    else:
        return redirect('/')

def viewapp(request):
    return render(request, 'applicationlist.html')

def index(request):
    return render(request,'index.html')

def register(request):
    return render(request,'register.html')

def login(request):
    return render(request,'login.html')

def about(request):
    return render(request,'about.html')

def application(request):
    if request.user.is_authenticated:
        return render(request,'application.html')
    else:
        return render(request,'login.html')


def registerform(request):

    if(request.method=='POST'):
       username=request.POST['username']
       email=request.POST['email']
       password=request.POST['password']
       password1=request.POST['password1']
       if(password1==password):
        if(User.objects.filter(username=username).exists()==False):
         if(User.objects.filter(email=email).exists()==False):
          user=User.objects.create_user(username=username,password=password1,email=email)
          user.save()

          api_url = masters_settings.MASTERS_POST_API

          if (request.method == 'POST'):
              id = request.user.id
              username = request.POST['username']
              firstName = int(request.POST['first_name'])
              lastName = request.POST['last_name']
              email = request.POST['email']
              password = request.POST['password']

              url = api_url + "/api/user"

              data = {
                  "id": int(id),
                  "username": username,
                  "firstName": firstName,
                  "LastName": lastName,
                  "email": email
              }

              cookie = str(uuid.uuid4())
              loginData = 'username=root&password=pass123'
              headers = {
                  'Authorization': 'Basic cm9vdDpwYXNzMTIz',
                  'Content-Type': 'application/json',
                  'Cookie': 'JSESSIONID=' + cookie
              }

          print("user added")
          return redirect('/')
         else:
             return render(request,'register.html',{'lol':'email is taken'})
        else:
            return render(request,'register.html',{'lol':'username does exist'})
       else:
           return render(request,'register.html',{'lol':'Passwords are not the same'})
    else:
        return render(request,'index.html')

def loginform(request):
    if(request.method=='POST'):
       username = request.POST['username']
       password = request.POST['password']
       user = auth.authenticate(username=username, password=password)
       if(user is not None):
           if(username == 'secretary'):
               return redirect('/masters/updateapproval.html')
           elif (username == 'professor'):
               return redirect('/masters/updateorder.html')
           else:
                auth.login(request, user)
           return redirect('/')
       else:
            return render(request, 'login.html', {'lol': "wrong password or username!"})

def logout(request):
    auth.logout(request)
    return redirect('/')

def applyform(request):

    api_url = masters_settings.MASTERS_POST_API

    if request.user.is_authenticated:

        if(request.method=='POST'):
            id = request.user.id
            undergraduate_studies = request.POST['undergraduate_studies']
            grade = int(request.POST['grade'])
            professor1 = request.POST['professor1']
            professor2 = request.POST['professor2']
            approval = request.POST['approval']
            order_number = int(request.POST['order_number'])

            url = api_url+"/api/application"

            data = {
                "id": int(id),
                "undergraduateStudies": undergraduate_studies,
                "grade": int(grade),
                "professor1": professor1,
                "professor2": professor2,
                "approval": approval,
                "orderNumber": int(order_number)
            }

            cookie = str(uuid.uuid4())
            loginData = 'username=root&password=pass123'
            headers = {
                'Authorization': 'Basic cm9vdDpwYXNzMTIz',
                'Content-Type': 'application/json',
                'Cookie': 'JSESSIONID='+cookie
            }


            with session() as c:
                c.post(api_url+"/authUser", headers=headers, data=loginData)
                response = c.post(url, data=json.dumps(data))
                print(response)
                return redirect('/')
        else:
            return redirect('/')
    else:
       return redirect('login.html')

def viewApplications(request):
    api_url = masters_settings.MASTERS_POST_API

    if request.user.is_authenticated:
        if (request.method == 'GET'):
            url = api_url + "/api/application"



            cookie = str(uuid.uuid4())
            loginData = 'username=root&password=pass123'
            headers = {
                'Authorization': 'Basic cm9vdDpwYXNzMTIz',
                'Content-Type': 'application/json',
                'Cookie': 'JSESSIONID=' + cookie
            }

            with session() as c:
                c.get(api_url + "/authUser", headers=headers, data=loginData)
                response = c.get(url)
                data = response.json()
                dataApp = json.loads(json.dumps(data))
                #with open("applications.json", "w") as write_file:
                #json.dump(data, write_file)
                print(response)
                print(data)
                #return redirect('/')
                return render(request, "applicationlist.html", {'dataApp': dataApp})
        else:
            return redirect('/')
    else:
        return redirect('login.html')

def updateSec(request):
    api_url = masters_settings.MASTERS_POST_API

    if request.user.is_authenticated:
        if request.method == 'PATCH':
            idAp = int(request.PATCH['id_ap'])
            approval = request.PATCH['approval']

            url = api_url + "/api/application/" + idAp

            data = {
                "id_ap": int(idAp),
                "approval": approval
            }

            cookie = str(uuid.uuid4())
            loginData = 'username=root&password=pass123'
            headers = {
                'Authorization': 'Basic cm9vdDpwYXNzMTIz',
                'Content-Type': 'application/json',
                'Cookie': 'JSESSIONID=' + cookie
            }

            with session() as c:
                c.patch(api_url + "/authUser", headers=headers, data=loginData)
                response = c.patch(url, data=json.dumps(data))
                print(response)
                return redirect('/')
        else:
            return redirect('/')
    else:
        return redirect('login.html')


def updateProf(request):
    api_url = masters_settings.MASTERS_POST_API

    if request.user.is_authenticated:
        if request.method == 'PATCH':
            idAp = int(request.PATCH['id_ap'])
            order_number = int(request.POST['order_number'])

            url = api_url + "/api/application/" + idAp

            data = {
                "approval": int(order_number)
            }

            cookie = str(uuid.uuid4())
            loginData = 'username=root&password=pass123'
            headers = {
                'Authorization': 'Basic cm9vdDpwYXNzMTIz',
                'Content-Type': 'application/json',
                'Cookie': 'JSESSIONID=' + cookie
            }

            with session() as c:
                c.patch(api_url + "/authUser", headers=headers, data=loginData)
                response = c.patch(url, data=json.dumps(data))
                print(response)
                return redirect('/')
        else:
            return redirect('/')
    else:
        return redirect('login.html')
