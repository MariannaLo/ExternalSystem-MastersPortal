from django.test import TestCase, Client
from masters.models import *
from django.contrib.auth.models import User


class TestApplication(TestCase):

    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='12345')
        self.client = Client()

    def test_sendApplication(self):
        login = self.client.login(username='testuser', password='12345')

        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        data = {
            'undergraduateStudies': "Informatics and Telematics",
            'grade': 7,
            'professor1': 'testProfessor1',
            'professor2': 'testProfessor2',
            'approval': 'yes',
            'orderNumber': 2
        }
        response = self.client.post('/apply', headers=headers, data=data)
        print(response)
